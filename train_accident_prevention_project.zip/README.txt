# Train Accident Prevention Project

This project uses an Arduino and an ultrasonic sensor to detect obstacles on the track and stop the train motor immediately.

## Components:
- Arduino Uno
- Ultrasonic Sensor (HC-SR04)
- Motor Driver (L298N) or transistor
- DC Motor (Train)

## Working:
If an obstacle is detected within 20cm of the train, the motor stops immediately to prevent accidents.

## Connections:
- Trig -> Pin 9
- Echo -> Pin 10
- Motor IN1 -> Pin 5
- Motor IN2 -> Pin 6
